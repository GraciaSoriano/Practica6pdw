// Operadores aritmeticos
let suma = 10+5
let resta = 20-5
let multiplicacion = 10*5
let division = 10/5
console.log(suma,resta,multiplicacion,division)

// Operadores de comparacion
let esMayor = 10 > 5
let esIgual = 10 == 10
let esEstrictamenteIgual = 10 === "10"
console.log(esMayor,esIgual,esEstrictamenteIgual)