let boton = document.getElementById("miBoton");

boton.addEventListener("click", function(){
    console.log("Boton clickeado")
    alert("Se hizo click en el boton")
})