// Condional if-else
let nota = 6;

if(nota >= 90){
    console.log("Excelente")
} else if (nota >= 70) {
    console.log("Aprobado has dejado de ser manco")
} else {
    console.log("Reprobado, demasiado manco")
}