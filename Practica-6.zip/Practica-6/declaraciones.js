//  Declaracion var (puede ser declarada y reasignada)
var nombre = 'Gracia'
console.log(nombre)

// Declaracion let
let edad = 21
console.log(edad)

//Declaracion const
const pais = 'El Salvador';
console.log(pais)